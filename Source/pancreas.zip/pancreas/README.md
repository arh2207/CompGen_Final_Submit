These files are human donors 1-3, csv files with indivdual cells annotated and
experimentally validated with IHC.  Papers linked here:

Supervised method: https://genomebiology.biomedcentral.com/articles/10.1186/s13059-019-1862-5
Original data generation: https://www.ncbi.nlm.nih.gov/pmc/articles/PMC5228327/

csv1: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSM2230757 
csv2: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSM2230758
csv3: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSM2230759
csv4: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSM2230760
